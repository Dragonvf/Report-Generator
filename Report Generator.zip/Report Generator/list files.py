import os

def list_png_files(directory):
    png_files = []
    for root, dirs, files in os.walk(directory):
        for file in files:
            if file.lower().endswith(".png"):
                png_files.append(file)
    return png_files

# Provide the directory path
directory_path = "C:/Users/jf_Wi/OneDrive/Desktop/TUV/Report Generator/data/Data"

# Call the function to get the list of PNG files
png_files_list = list_png_files(directory_path)

# Print the list of PNG file names
for file_name in png_files_list:
    print(file_name)


# # print directory
# def list_png_files_directory(directory):
#     png_files = []
#     for root, dirs, files in os.walk(directory):
#         for file in files:
#             if file.lower().endswith(".png"):
#                 png_files.append(os.path.join(root, file))
#     return png_files

# # Provide the directory path
# directory_path = "C:/Users/jf_Wi/OneDrive/Desktop/TUV/Report Generator/data/Data"

# # Call the function to get the list of PNG files
# png_files_list = list_png_files_directory(directory_path)

# # Print the list of PNG files
# for file_path in png_files_list:
#     print(file_path)
