from docx import Document
from docx.shared import Cm
from docx.enum.text import WD_PARAGRAPH_ALIGNMENT
import os

def insert_images(template_file, target_text, image_dir, output_file):
    # Load the template document
    doc = Document(template_file)

    # Find the target text in the document
    found_text = False
    for paragraph in doc.paragraphs:
        if target_text in paragraph.text:
            found_text = True
            target_paragraph = paragraph
            break

    # If the target text is found, insert images
    if found_text:
        for filename in os.listdir(image_dir):
            if filename.endswith(".png"):
                image_path = os.path.join(image_dir, filename)
                image_paragraph = target_paragraph.insert_paragraph_before()
                image_paragraph.alignment = WD_PARAGRAPH_ALIGNMENT.CENTER
                run = image_paragraph.add_run()
                picture = run.add_picture(image_path)
                width = picture.width
                height = picture.height
                picture.width = int(width * 0.35)  # Scale the width to 30%
                picture.height = int(height * 0.35)  # Scale the height to 30%
                name_paragraph = target_paragraph.insert_paragraph_before()
                name_paragraph.alignment = WD_PARAGRAPH_ALIGNMENT.CENTER
                name_paragraph.add_run(filename)
                name_paragraph.add_run("\n")  # Add a new line after the filename

        # Delete the target text
        target_paragraph.text = target_paragraph.text.replace(target_text, "")

        # Save the document with a new name
        doc.save(output_file)
        print(f"Images inserted and target text deleted. Document saved as {output_file}.")
    else:
        print("Target text not found in the document.")

# Specify the file paths
template_file = "temp.docx"
target_text = "Template_place_holder"
image_dir = "C:/Users/jf_Wi/OneDrive/Desktop/TUV/Report Generator/data/Data"
output_file = "test.docx"

# Call the function to perform the tasks
insert_images(template_file, target_text, image_dir, output_file)
